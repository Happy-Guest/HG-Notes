<?php

// config/fcm.php

return [
    'token' => "AAAAwE52K4M:APA91bEbxDjDkudQTsNiB9XAQs9sO0k1eZoA0qRbXFtswreNeDWqtqJQipj1b57wsozW6y9WdH_pKDkA_fqc0kVwCOalyBK7n0e7Vj9KWAl7wXwulNYj2oQG6sN2EQHapOk8JOqQSvxG",
];
