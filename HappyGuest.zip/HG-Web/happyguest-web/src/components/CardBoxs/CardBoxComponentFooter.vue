<template>
    <footer class="px-6 pb-6 pt-3">
        <slot />
    </footer>
</template>
