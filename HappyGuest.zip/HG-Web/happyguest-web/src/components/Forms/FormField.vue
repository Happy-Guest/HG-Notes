<script setup>
import { computed, useSlots } from "vue";

const props = defineProps({
    label: {
        type: String,
        default: null,
    },
    labelFor: {
        type: String,
        default: null,
    },
    help: {
        type: String,
        default: null,
    },
    flex: {
        type: Boolean,
        default: false,
    },
    noMargin: {
        type: Boolean,
        default: false,
    },
});

const slots = useSlots();

const wrapperClass = computed(() => {
    const base = [];
    const slotsLength = slots.default().length;

    if (slotsLength > 1 && !props.flex) {
        base.push("grid grid-cols-1 gap-3");
    }

    if (props.flex) {
        base.push("flex flex-wrap sm:flex-nowrap gap-3 justify-between");
    }

    if (slotsLength === 2) {
        base.push("md:grid-cols-2");
    }

    return base;
});
</script>

<template>
    <div :class="props.noMargin ? 'mb-2 md:mb-0' : 'mb-6 last:mb-0'">
        <label v-if="label" :for="labelFor" class="block font-bold mb-2">{{
            label
        }}</label>
        <div :class="wrapperClass">
            <slot />
        </div>
        <div v-if="help" class="text-xs text-gray-500 dark:text-slate-400 mt-1">
            {{ help }}
        </div>
    </div>
</template>
