export const darkModeKey = "darkMode";

export const styleKey = "style";

export const containerMaxW = "xl:max-w-6xl xl:mx-auto";
