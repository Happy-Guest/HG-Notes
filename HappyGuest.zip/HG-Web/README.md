# ✒️ Happy Guest - Web
Projeto Informático -> IPL 22/23

Desenvolvimento de um dashboard web que permita 
gerir os dados de uma unidade hoteleira.

## 📖 Notas:
1. Instalação: 
    * npm install
2. URL:
    * WEB -> http://127.0.0.1:5173/happyguest-web/
    
3. Iniciar:
    * npm run dev
    * npm run lint -> (fixs)

## 🧑 Participantes:
* Diogo Mendes nº2191181 -> 2191181@ipleiria.pt
* Tomás Neves nº221747 -> 221747@ipleiria.pt

## 🔧 Info:
Engenharia Informática

Vue
